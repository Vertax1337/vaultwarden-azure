Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$moduleRoot = Join-Path $PSScriptRoot '..\modules\ConsoleMenu'
Import-Module $moduleRoot -Force

function Assert-Equal {
    param(
        [Parameter(Mandatory)]$Actual,
        [Parameter(Mandatory)]$Expected,
        [Parameter(Mandatory)][string]$Message
    )

    if ($Actual -ne $Expected) {
        throw ('ASSERT FAILED: {0} | Expected="{1}" Actual="{2}"' -f $Message, $Expected, $Actual)
    }
}

$mainMenu = New-ConsoleMenu -Id 'Main' -Title 'Main' -DefaultKey '1' -Items @(
    (New-ConsoleMenuItem -Key '1' -Text 'Sub' -ItemType 'submenu' -TargetMenuId 'SubMenu')
    (New-ConsoleMenuItem -Key '2' -Text 'Disabled' -ItemType 'action' -ActionId 'DisabledAction' -Enabled:$false)
    (New-ConsoleMenuItem -Key '0' -Text 'Exit' -ItemType 'exit')
)

$subMenu = New-ConsoleMenu -Id 'SubMenu' -Title 'SubMenu' -DefaultKey '1' -Items @(
    (New-ConsoleMenuItem -Key '1' -Text 'Action' -ItemType 'action' -ActionId 'DoThing')
    (New-ConsoleMenuItem -Key '0' -Text 'Back' -ItemType 'back')
)

$registry = @{
    Main = $mainMenu
    SubMenu = $subMenu
}

$menuState = @{}
$menuState['Main'] = '0'
$menuState['SubMenu'] = '1'

Assert-Equal -Actual $mainMenu.Id -Expected 'Main' -Message 'Menuedefinition erstellt'
Assert-Equal -Actual (Get-ConsoleMenuById -MenuRegistry $registry -MenuId 'SubMenu').Title -Expected 'SubMenu' -Message 'Registry-Lookup'
Assert-Equal -Actual (Get-ConsoleMenuDefaultIndex -Items $mainMenu.Items -DefaultKey '1') -Expected 0 -Message 'DefaultIndex Main'
Assert-Equal -Actual (Get-ConsoleMenuDefaultIndex -Items $mainMenu.Items -DefaultKey '0') -Expected 2 -Message 'Gemerkte Auswahl Main'
Assert-Equal -Actual (Get-ConsoleMenuDefaultIndex -Items $subMenu.Items -DefaultKey '1') -Expected 0 -Message 'Gemerkte Auswahl SubMenu'
Assert-Equal -Actual (Get-ConsoleMenuNextIndex -Items $mainMenu.Items -CurrentIndex 0 -Step 1) -Expected 2 -Message 'Disabled Eintrag wird uebersprungen'
Assert-Equal -Actual (Get-ConsoleMenuNextIndex -Items $mainMenu.Items -CurrentIndex 2 -Step 1) -Expected 0 -Message 'Wrap nach unten'
Assert-Equal -Actual $mainMenu.Items[0].ItemType -Expected 'submenu' -Message 'Submenu-Type gesetzt'
Assert-Equal -Actual $subMenu.Items[1].ItemType -Expected 'back' -Message 'Back-Type gesetzt'

Write-Host 'Alle Smoke-Tests erfolgreich.'
