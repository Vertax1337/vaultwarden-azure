Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$moduleRoot = Join-Path $PSScriptRoot 'modules\ConsoleMenu'
Import-Module $moduleRoot -Force

$menuRegistry = @{
    Main = (New-ConsoleMenu -Id 'Main' -Title 'Stammmenue' -DefaultKey '1' -Items @(
        (New-ConsoleMenuItem -Key '1' -Text 'Neues Kundendeployment anlegen und deployen' -ItemType 'submenu' -TargetMenuId 'DeployMenu')
        (New-ConsoleMenuItem -Key '2' -Text 'Vorhandene Konfiguration deployen' -ItemType 'action' -ActionId 'DeployExisting')
        (New-ConsoleMenuItem -Key '3' -Text 'Vorhandene Konfiguration bearbeiten und deployen' -ItemType 'action' -ActionId 'EditAndDeploy')
        (New-ConsoleMenuItem -Key '4' -Text 'Maintenance / Repair / Update' -ItemType 'submenu' -TargetMenuId 'MaintenanceMenu')
        (New-ConsoleMenuItem -Key '6' -Text 'Nur Kunden-/Parameterdateien erzeugen' -ItemType 'action' -ActionId 'GenerateOnly')
        (New-ConsoleMenuItem -Key '0' -Text 'Beenden' -ItemType 'exit')
    ))

    DeployMenu = (New-ConsoleMenu -Id 'DeployMenu' -Title 'Untermenue: Deployment' -DefaultKey '1' -Items @(
        (New-ConsoleMenuItem -Key '1' -Text 'Neue Konfiguration anlegen' -ItemType 'action' -ActionId 'NewConfig')
        (New-ConsoleMenuItem -Key '2' -Text 'Vorhandene Konfiguration bearbeiten' -ItemType 'action' -ActionId 'EditConfig')
        (New-ConsoleMenuItem -Key '3' -Text 'Erweiterte Deploymentoptionen' -ItemType 'submenu' -TargetMenuId 'AdvancedDeployMenu')
        (New-ConsoleMenuItem -Key '0' -Text 'Zurueck' -ItemType 'back')
    ))

    AdvancedDeployMenu = (New-ConsoleMenu -Id 'AdvancedDeployMenu' -Title 'Untermenue: Erweiterte Deploymentoptionen' -DefaultKey '1' -Items @(
        (New-ConsoleMenuItem -Key '1' -Text 'Dry-Run' -ItemType 'action' -ActionId 'DryRun')
        (New-ConsoleMenuItem -Key '2' -Text 'Validierung' -ItemType 'action' -ActionId 'Validate')
        (New-ConsoleMenuItem -Key '0' -Text 'Zurueck' -ItemType 'back')
    ))

    MaintenanceMenu = (New-ConsoleMenu -Id 'MaintenanceMenu' -Title 'Untermenue: Maintenance' -DefaultKey '1' -Items @(
        (New-ConsoleMenuItem -Key '1' -Text 'Repair mit vorhandener Konfiguration' -ItemType 'action' -ActionId 'Repair')
        (New-ConsoleMenuItem -Key '2' -Text 'Update mit vorhandener Konfiguration' -ItemType 'action' -ActionId 'Update')
        (New-ConsoleMenuItem -Key '0' -Text 'Zurueck' -ItemType 'back')
    ))
}

$actionHandler = {
    param(
        $SelectedItem,
        $CurrentMenu,
        $MenuRegistry,
        $MenuStack,
        $MenuState
    )

    $currentPath = ($MenuStack.ToArray() -join ' > ')
    $lastSelection = $MenuState[$CurrentMenu.Id]

    switch ($SelectedItem.ActionId) {
        'DeployExisting' {
            Show-ConsoleScreenMessage -Title 'Vorhandene Konfiguration deployen' -Message ('Aktion 2 ausgewaehlt | Kontext: {0} | Marker bleibt auf [{1}]' -f $currentPath, $lastSelection)
        }

        'EditAndDeploy' {
            Show-ConsoleScreenMessage -Title 'Vorhandene Konfiguration bearbeiten und deployen' -Message ('Aktion 3 ausgewaehlt | Kontext: {0} | Marker bleibt auf [{1}]' -f $currentPath, $lastSelection)
        }

        'GenerateOnly' {
            Show-ConsoleScreenMessage -Title 'Nur Kunden-/Parameterdateien erzeugen' -Message ('Aktion 6 ausgewaehlt | Kontext: {0} | Marker bleibt auf [{1}]' -f $currentPath, $lastSelection)
        }

        'NewConfig' {
            Show-ConsoleScreenMessage -Title 'Neue Konfiguration' -Message ('Neue Konfiguration ausgewaehlt | Rueckkehr nach: {0} | Marker bleibt auf [{1}]' -f $CurrentMenu.Title, $lastSelection)
        }

        'EditConfig' {
            Show-ConsoleScreenMessage -Title 'Vorhandene Konfiguration bearbeiten' -Message ('Bearbeiten ausgewaehlt | Rueckkehr nach: {0} | Marker bleibt auf [{1}]' -f $CurrentMenu.Title, $lastSelection)
        }

        'DryRun' {
            Show-ConsoleScreenMessage -Title 'Dry-Run' -Message ('Dry-Run ausgewaehlt | Rueckkehr nach: {0} | Marker bleibt auf [{1}]' -f $CurrentMenu.Title, $lastSelection)
        }

        'Validate' {
            Show-ConsoleScreenMessage -Title 'Validierung' -Message ('Validierung ausgewaehlt | Rueckkehr nach: {0} | Marker bleibt auf [{1}]' -f $CurrentMenu.Title, $lastSelection)
        }

        'Repair' {
            Show-ConsoleScreenMessage -Title 'Repair' -Message ('Repair ausgewaehlt | Rueckkehr nach: {0} | Marker bleibt auf [{1}]' -f $CurrentMenu.Title, $lastSelection)
        }

        'Update' {
            Show-ConsoleScreenMessage -Title 'Update' -Message ('Update ausgewaehlt | Rueckkehr nach: {0} | Marker bleibt auf [{1}]' -f $CurrentMenu.Title, $lastSelection)
        }

        default {
            Show-ConsoleScreenMessage -Title 'Aktion' -Message ('Unbekannte ActionId: {0}' -f $SelectedItem.ActionId)
        }
    }
}

$result = Start-ConsoleMenuApplication -MenuRegistry $menuRegistry -RootMenuId 'Main' -ActionHandler $actionHandler

if ($result.ExitRequested) {
    exit 0
}

exit 1
