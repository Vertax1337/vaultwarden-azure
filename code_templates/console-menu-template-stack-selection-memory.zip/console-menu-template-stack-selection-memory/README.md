# PowerShell Console Menu Template (Stack + Selection Memory)

Diese Version merkt sich **pro Menü die letzte Auswahl**.

## Neues Verhalten

Wenn du:
- in ein Untermenü wechselst
- dort einen Punkt auswählst
- auf einen Aktionsscreen gehst
- wieder zurückkehrst

dann landest du:
1. im **zuletzt geöffneten Menü**
2. mit dem Marker auf dem **zuletzt ausgewählten Eintrag**

## Technisches Konzept

Zusätzlich zur Stack-Navigation gibt es jetzt einen internen `menuState`-Speicher:

```powershell
$menuState['DeployMenu'] = '3'
$menuState['MaintenanceMenu'] = '2'
```

Beim erneuten Öffnen eines Menüs wird zuerst geprüft:
- gibt es eine gemerkte Auswahl für dieses Menü?
- wenn ja: darauf setzen
- wenn nein: `DefaultKey` verwenden

## Architektur

- **Menu Registry**
- **Menu Stack**
- **Selection Memory pro Menü**
- **Action Handler**

## Erweiterung

Neue Menüs fügst du weiter nur als Daten hinzu.
Die Auswahl-Merkung funktioniert automatisch für alle registrierten Menüs.

## Dateien

- `Start-MainMenuTemplate.ps1`
- `modules/ConsoleMenu/ConsoleMenu.psm1`
- `modules/ConsoleMenu/ConsoleMenu.psd1`
- `tests/Run-SmokeTests.ps1`
- `README.md`
